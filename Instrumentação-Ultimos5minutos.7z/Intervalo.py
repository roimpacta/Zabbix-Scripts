#!/usr/bin/python


from datetime import datetime, timedelta

now = datetime.now()
before = timedelta(minutes=5)
now = now.replace(microsecond=0)
now = now.replace(second=0)
before = (now-before)
now = (now.strftime("%H:%M:"))
before = (before.strftime("%H:%M:"))

contador = 0
x =open('user.log','r')
for line in x:
    if before in line:
        break

for line in x:
    if now in line:
        break

    if "err|error" in line.strip():
        contador = contador+1
print(contador)


