#!/bin/bash

tmpLog="/cbssconfig/logs/Web/log_mc_bi.txt"
tmpMCBI="/home/zabxadm/mc_bi_files/MCBI`date +%Y%m%d`.csv"

#-----------------------executa 1x script

var=$(cat $tmpLog | grep -a "Hora do" | awk {'print $5'} | awk -F':' '{print $1 * 60 * 60 + $2 * 60 + $3}')
var1=$(cat $tmpLog | grep -i -B 1 "rio permitido para processamento do MCBI" | grep Agora | awk {'print $6'} | awk -F':' '{print $1 * 60 * 60 + $2 * 60 + $3}')
let tempo=$var-$var1


case $1 in
Inic)
cat $tmpLog | grep -i -B 1 "rio permitido para processamento do MCBI" | grep Agora | awk {'print $6'}
;;
Term)
cat $tmpLog | grep -a "Hora do" | awk {'print $5'}
;;
Tempo)
echo $tempo
;;
CA)
cat $tmpMCBI | grep "Contratos atualizados" | awk {'print $NF'}
;;
CI)
cat $tmpMCBI | grep "Contratos inseridos" | awk {'print $NF'}
;;
CL)
cat $tmpMCBI | grep "Contratos lidos" | awk {'print $NF'}
;;
CN)
cat $tmpMCBI | grep "atualizados por outros erros" | awk {'print $NF'}
;;
EA)
cat $tmpMCBI | grep "Empresas atualizadas" | awk {'print $NF'}
;;
EI)
cat $tmpMCBI | grep "Empresas inseridas" | awk {'print $NF'}
;;
EL)
cat $tmpMCBI | grep "Empresas lidas" | awk {'print $NF'}
;;
EN)
cat $tmpMCBI | grep "Empresas n" | awk {'print $NF'}
;;
ErroInter)
cat $tmpMCBI | grep "Erros ao inserir interlocutor" | awk {'print $NF'}
;;
FA)
cat $tmpMCBI | grep "FCs atualizadas" | awk {'print $NF'}
;;
FI)
cat $tmpMCBI | grep "FCs inseridas" | awk {'print $NF'}
;;
FL)
cat $tmpMCBI | grep "FCs lidas" | awk {'print $NF'}
;;
FN)
cat $tmpMCBI | grep "FCs n" | awk {'print $NF'}
;;
FiA)
cat $tmpMCBI | grep "Filiais atualizadas	:" | awk {'print $NF'}
;;
FiattIl)
cat $tmpMCBI | grep "Filiais atualizadas com os interlocutores lidos" | awk {'print $NF'}
;;
FiI)
cat $tmpMCBI | grep "Filiais inseridas" | awk {'print $NF'}
;;
FiL)
cat $tmpMCBI | grep "Filiais lidas" | awk {'print $NF'}
;;
FiNatt)
cat $tmpMCBI | grep "atualizadas por outros erros" | awk {'print $NF'}
;;
FiNi)
cat $tmpMCBI | grep "atualizadas porque o interlocutor lido" | awk {'print $NF'}
;;
FiBd)
cat $tmpMCBI | grep "existiam no BD" | awk {'print $NF'}
;;
IA)
cat $tmpMCBI | grep "Interlocutores atualizados" | awk {'print $NF'}
;;
II)
cat $tmpMCBI | grep "Interlocutores inseridos:" | awk {'print $NF'}
;;
IIcnd)
cat $tmpMCBI | grep "Interlocutores inseridos apenas com CPF, NOME e DT_NASCIMENTO" | awk {'print $NF'}
;;
IIdc)
cat $tmpMCBI | grep "Interlocutores inseridos com dados de contato" | awk {'print $NF'}
;;
TI)
cat $tmpMCBI | grep "Total de interlocutores sem c" | awk {'print $NF'}
;;
IL)
cat $tmpMCBI | grep "Interlocutores lidos" | awk {'print $NF'}
;;
Ifd)
cat $tmpMCBI | grep "inseridos por falta de dados" | awk {'print $NF'}
;;
esac
