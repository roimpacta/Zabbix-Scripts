#!/bin/bash
tmp="/var/adm"


case $1 in
Error)
cat $tmp/user.log | grep "err|error" | wc -l
;;
esac
